package com.winlator.cmod.renderer.effects;

import android.opengl.GLES20;
import android.util.Log;

import com.winlator.cmod.renderer.GLRenderer;
import com.winlator.cmod.renderer.material.ScreenMaterial;

public class VREffect extends Effect {
    private boolean vrEnabled = false;
    private boolean showCenterLine = false;
    private float centerLineColor = 1.0f;
    private boolean syncFrames = true;
    private int vrMode = 0; // 0=Split Screen, 1=Side-by-Side, 2=Over-Under
    private float leftFrameX = 0.0f, leftFrameY = 0.0f, leftFrameWidth = 0.5f, leftFrameHeight = 1.0f;
    private float rightFrameX = 0.5f, rightFrameY = 0.0f, rightFrameWidth = 0.5f, rightFrameHeight = 1.0f;
    private float distortionStrength = 0.2f; // Сила коррекции "рыбий глаз"
    private float edgeFeathering = 0.05f;
    private float cornerRadius = 0.1f;
    private GLRenderer renderer;

    public VREffect() {
        super();
    }

    public void setRenderer(GLRenderer renderer) {
        this.renderer = renderer;
    }

    @Override
    protected ScreenMaterial createMaterial() {
        return new VREffectMaterial();
    }

    // Методы для управления VR режимом
    public void setEnabled(boolean enabled) {
        this.vrEnabled = enabled;
    }

    public boolean isEnabled() {
        return vrEnabled;
    }

    public void setVREnabled(boolean enabled) {
        this.vrEnabled = enabled;
    }

    public boolean isVREnabled() {
        return vrEnabled;
    }

    // Методы для отображения центральной линии
    public void setShowCenterLine(boolean show) {
        this.showCenterLine = show;
    }

    public boolean isShowCenterLine() {
        return showCenterLine;
    }

    public void setCenterLineColor(float color) {
        this.centerLineColor = color;
    }

    public float getCenterLineColor() {
        return centerLineColor;
    }

    // Методы для VR режима
    public void setVrMode(int mode) {
        this.vrMode = mode;
    }

    public int getVrMode() {
        return vrMode;
    }

    // Методы для синхронизации фреймов
    public void setSyncFrames(boolean sync) {
        this.syncFrames = sync;
    }

    public boolean isSyncFrames() {
        return syncFrames;
    }

    // Методы для левого фрейма
    public void setLeftFrameX(float x) {
        this.leftFrameX = x;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getLeftFrameX() {
        return leftFrameX;
    }

    public void setLeftFrameY(float y) {
        this.leftFrameY = y;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getLeftFrameY() {
        return leftFrameY;
    }

    public void setLeftFrameWidth(float width) {
        this.leftFrameWidth = width;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getLeftFrameWidth() {
        return leftFrameWidth;
    }

    public void setLeftFrameHeight(float height) {
        this.leftFrameHeight = height;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getLeftFrameHeight() {
        return leftFrameHeight;
    }

    // Методы для правого фрейма
    public void setRightFrameX(float x) {
        this.rightFrameX = x;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getRightFrameX() {
        return rightFrameX;
    }

    public void setRightFrameY(float y) {
        this.rightFrameY = y;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getRightFrameY() {
        return rightFrameY;
    }

    public void setRightFrameWidth(float width) {
        this.rightFrameWidth = width;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getRightFrameWidth() {
        return rightFrameWidth;
    }

    public void setRightFrameHeight(float height) {
        this.rightFrameHeight = height;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getRightFrameHeight() {
        return rightFrameHeight;
    }

    // Методы для параметров дисторсии
    public void setDistortionStrength(float strength) {
        this.distortionStrength = strength;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getDistortionStrength() {
        return distortionStrength;
    }

    public void setEdgeFeathering(float feathering) {
        this.edgeFeathering = feathering;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getEdgeFeathering() {
        return edgeFeathering;
    }

    public void setCornerRadius(float radius) {
        this.cornerRadius = radius;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public float getCornerRadius() {
        return cornerRadius;
    }

    // Метод для сброса к значениям по умолчанию
    public void resetToDefaults() {
        vrEnabled = false;
        showCenterLine = false;
        centerLineColor = 1.0f;
        vrMode = 0; // Split screen
        syncFrames = true;
        
        // Установка стандартных значений для Google Cardboard
        leftFrameX = 0.0f;
        leftFrameY = 0.0f;
        leftFrameWidth = 0.5f;  // Левая половина
        leftFrameHeight = 1.0f;
        
        rightFrameX = 0.5f;     // Правая половина
        rightFrameY = 0.0f;
        rightFrameWidth = 0.5f;
        rightFrameHeight = 1.0f;
        
        distortionStrength = 0.2f; // Умеренная коррекция рыбий глаз
        edgeFeathering = 0.05f; // Небольшое размытие краев
        cornerRadius = 0.1f;    // Закругление углов
        
        if (renderer != null) renderer.xServerView.requestRender();
    }

    // Методы для установки параметров фрейма (для совместимости)
    public void setLeftFrameParams(float x, float y, float width, float height) {
        this.leftFrameX = x;
        this.leftFrameY = y;
        this.leftFrameWidth = width;
        this.leftFrameHeight = height;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    public void setRightFrameParams(float x, float y, float width, float height) {
        this.rightFrameX = x;
        this.rightFrameY = y;
        this.rightFrameWidth = width;
        this.rightFrameHeight = height;
        if (renderer != null) renderer.xServerView.requestRender();
    }

    private class VREffectMaterial extends ScreenMaterial {
        public VREffectMaterial() {
            super();
            setUniformNames("resolution", "screenTexture", "vrEnabled", "showCenterLine", "centerLineColor", "vrMode",
                          "syncFrames",
                          "leftFrameX", "leftFrameY", "leftFrameWidth", "leftFrameHeight",
                          "rightFrameX", "rightFrameY", "rightFrameWidth", "rightFrameHeight",
                          "distortionStrength", "edgeFeathering", "cornerRadius");
        }

        @Override
        protected String getFragmentShader() {
            return String.join("\n", new CharSequence[]{
                "precision highp float;",
                "uniform vec2 resolution;",
                "uniform sampler2D screenTexture;",
                "uniform bool vrEnabled;",
                "uniform bool showCenterLine;",
                "uniform float centerLineColor;",
                "uniform int vrMode;",
                "uniform bool syncFrames;",
                "uniform float leftFrameX, leftFrameY, leftFrameWidth, leftFrameHeight;",
                "uniform float rightFrameX, rightFrameY, rightFrameWidth, rightFrameHeight;",
                "uniform float distortionStrength;",
                "uniform float edgeFeathering;",
                "uniform float cornerRadius;",
                "varying vec2 vUV;",

                // Функция коррекции "рыбий глаз" для компенсации искажений линз cardboard
                "vec2 barrelDistortion(vec2 uv, float strength) {",
                "    vec2 center = vec2(0.5, 0.5);",
                "    vec2 centeredUV = uv - center;",
                "    float r = length(centeredUV);",
                "    float theta = atan(centeredUV.y, centeredUV.x);",
                "    ",
                "    // Квадратичная коррекция для компенсации искажений",
                "    float correctedR = r * (1.0 + strength * r * r);",
                "    ",
                "    vec2 correctedUV = center + correctedR * vec2(cos(theta), sin(theta));",
                "    return correctedUV;",
                "}",

                // Функция для создания маски с закругленными углами для каждого фрейма
                "float roundedFrameMask(vec2 uv, float frameX, float frameY, float frameWidth, float frameHeight, float cornerRadius) {",
                "    // Нормализуем UV координаты в систему координат фрейма",
                "    vec2 frameUV = (uv - vec2(frameX, frameY)) / vec2(frameWidth, frameHeight);",
                "    ",
                "    // Проверяем, находится ли точка внутри фрейма",
                "    if (frameUV.x < 0.0 || frameUV.x > 1.0 || frameUV.y < 0.0 || frameUV.y > 1.0) {",
                "        return 0.0;",
                "    }",
                "    ",
                "    // Вычисляем расстояние до краев фрейма",
                "    vec2 distanceToCenter = abs(frameUV - 0.5);",
                "    vec2 distanceToEdge = vec2(0.5) - distanceToCenter;",
                "    ",
                "    // Определяем размер скругления",
                "    float radius = min(frameWidth, frameHeight) * cornerRadius;",
                "    ",
                "    // Вычисляем маску скругления",
                "    vec2 cornerDistance = vec2(0.5 - radius) - distanceToCenter;",
                "    float cornerMask = 1.0 - smoothstep(0.0, edgeFeathering, length(max(vec2(0.0), cornerDistance)));",
                "    ",
                "    // Объединяем маску фрейма и маску скругления",
                "    float frameMask = smoothstep(0.0, edgeFeathering, distanceToEdge.x) *",
                "                     smoothstep(0.0, edgeFeathering, distanceToEdge.y);",
                "    ",
                "    return min(frameMask, cornerMask);",
                "}",

                "void main() {",
                "    if (!vrEnabled) {",
                "        // Обычный режим - просто выводим оригинальное изображение",
                "        gl_FragColor = texture2D(screenTexture, vUV);",
                "        return;",
                "    }",
                "",
                "    vec4 finalColor;",
                "    ",
                "    // Определяем, какую половину экрана мы рендерим",
                "    if (vUV.x < 0.5) {",  // Левая половина экрана",
                "        // Применяем коррекцию рыбий глаз к UV координатам",
                "        vec2 correctedUV = barrelDistortion(vUV, distortionStrength);",
                "        ",
                "        // Вычисляем UV координаты для левого изображения",
                "        vec2 leftUV = vec2(",
                "            (correctedUV.x - leftFrameX) / leftFrameWidth,",
                "            (correctedUV.y - leftFrameY) / leftFrameHeight",
                "        );",
                "        ",
                "        // Проверяем, находится ли точка внутри левого фрейма с закруглением",
                "        float leftFrameMask = roundedFrameMask(vUV, leftFrameX, leftFrameY, leftFrameWidth, leftFrameHeight, cornerRadius);",
                "        ",
                "        if (leftUV.x >= 0.0 && leftUV.x <= 1.0 && leftUV.y >= 0.0 && leftUV.y <= 1.0 && leftFrameMask > 0.0) {",
                "            vec4 color = texture2D(screenTexture, leftUV);",
                "            finalColor = vec4(color.rgb * leftFrameMask, color.a);",
                "        } else {",
                "            // Вне фрейма - черный цвет",
                "            finalColor = vec4(0.0, 0.0, 0.0, 1.0);",
                "        }",
                "    } else {",  // Правая половина экрана",
                "        // Применяем коррекцию рыбий глаз к UV координатам",
                "        vec2 correctedUV = barrelDistortion(vUV, distortionStrength);",
                "        ",
                "        vec2 rightUV;",
                "        if (syncFrames) {",
                "            // Если синхронизация включена, используем левые параметры для правого глаза",
                "            rightUV = vec2(",
                "                (correctedUV.x - (leftFrameX + 0.5)) / leftFrameWidth,",
                "                (correctedUV.y - leftFrameY) / leftFrameHeight",
                "            );",
                "        } else {",
                "            // Используем отдельные параметры для правого глаза",
                "            rightUV = vec2(",
                "                (correctedUV.x - rightFrameX) / rightFrameWidth,",
                "                (correctedUV.y - rightFrameY) / rightFrameHeight",
                "            );",
                "        }",
                "        ",
                "        // Проверяем, находится ли точка внутри правого фрейма с закруглением",
                "        float rightFrameMask = roundedFrameMask(vUV, rightFrameX, rightFrameY, rightFrameWidth, rightFrameHeight, cornerRadius);",
                "        ",
                "        if (rightUV.x >= 0.0 && rightUV.x <= 1.0 && rightUV.y >= 0.0 && rightUV.y <= 1.0 && rightFrameMask > 0.0) {",
                "            vec4 color = texture2D(screenTexture, rightUV);",
                "            finalColor = vec4(color.rgb * rightFrameMask, color.a);",
                "        } else {",
                "            // Вне фрейма - черный цвет",
                "            finalColor = vec4(0.0, 0.0, 0.0, 1.0);",
                "        }",
                "    }",
                "",
                "    // Добавляем вертикальную линию по центру экрана, если нужно",
                "    if (showCenterLine) {",
                "        float centerLineWidth = 0.002; // Толщина линии (0.2% ширины экрана)",
                "        float centerLinePosition = 0.5; // Центр экрана",
                "        float distanceFromCenter = abs(vUV.x - centerLinePosition);",
                "        float lineMask = 1.0 - smoothstep(0.0, centerLineWidth, distanceFromCenter);",
                "        vec3 lineColor = vec3(centerLineColor);",
                "        finalColor = mix(finalColor, vec4(lineColor, 1.0), lineMask);",
                "    }",
                "",
                "    gl_FragColor = finalColor;",
                "}"
            });
        }

        @Override
        public void use() {
            super.use();

            setUniformInt("vrEnabled", vrEnabled ? 1 : 0);
            setUniformInt("showCenterLine", showCenterLine ? 1 : 0);
            setUniformFloat("centerLineColor", centerLineColor);
            setUniformInt("vrMode", vrMode);
            setUniformInt("syncFrames", syncFrames ? 1 : 0);
            
            // Устанавливаем параметры фреймов
            setUniformFloat("leftFrameX", leftFrameX);
            setUniformFloat("leftFrameY", leftFrameY);
            setUniformFloat("leftFrameWidth", leftFrameWidth);
            setUniformFloat("leftFrameHeight", leftFrameHeight);
            
            setUniformFloat("rightFrameX", rightFrameX);
            setUniformFloat("rightFrameY", rightFrameY);
            setUniformFloat("rightFrameWidth", rightFrameWidth);
            setUniformFloat("rightFrameHeight", rightFrameHeight);
            
            // Устанавливаем параметры дисторсии и закругления
            setUniformFloat("distortionStrength", distortionStrength);
            setUniformFloat("edgeFeathering", edgeFeathering);
            setUniformFloat("cornerRadius", cornerRadius);
        }
    }
}