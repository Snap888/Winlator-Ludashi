package com.winlator.cmod.renderer.effects;

import android.opengl.GLES20;
import android.util.Log;

import com.winlator.cmod.renderer.GLRenderer;
import com.winlator.cmod.renderer.material.ScreenMaterial;

public class VREffect extends Effect {
    private boolean vrEnabled = false;
    private boolean showCenterLine = false;
    private float centerLineColor = 1.0f;
    private boolean syncFrames = true;
    private int vrMode = 0; // 0=Split Screen, 1=Side-by-Side, 2=Over-Under
    private float leftFrameX = 0.0f, leftFrameY = 0.0f, leftFrameWidth = 0.5f, leftFrameHeight = 1.0f;
    private float rightFrameX = 0.5f, rightFrameY = 0.0f, rightFrameWidth = 0.5f, rightFrameHeight = 1.0f;
    private float distortionStrength = 0.3f; // Умеренная дисторсия для компенсации линз
    private float edgeFeathering = 0.02f;
    private float cornerRadius = 0.05f; // Меньше закругление
    private GLRenderer renderer;

    public VREffect() {
        super();
    }

    public void setRenderer(GLRenderer renderer) {
        this.renderer = renderer;
    }

    @Override
    protected ScreenMaterial createMaterial() {
        return new VREffectMaterial();
    }

    // Методы для управления VR режимом
    public void setEnabled(boolean enabled) {
        this.vrEnabled = enabled;
    }

    public boolean isEnabled() {
        return vrEnabled;
    }

    public void setVREnabled(boolean enabled) {
        this.vrEnabled = enabled;
    }

    public boolean isVREnabled() {
        return vrEnabled;
    }

    // Методы для отображения центральной линии
    public void setShowCenterLine(boolean show) {
        this.showCenterLine = show;
    }

    public boolean isShowCenterLine() {
        return showCenterLine;
    }

    public void setCenterLineColor(float color) {
        this.centerLineColor = color;
    }

    public float getCenterLineColor() {
        return centerLineColor;
    }

    // Методы для VR режима
    public void setVrMode(int mode) {
        this.vrMode = mode;
    }

    public int getVrMode() {
        return vrMode;
    }

    // Методы для синхронизации фреймов
    public void setSyncFrames(boolean sync) {
        this.syncFrames = sync;
    }

    public boolean isSyncFrames() {
        return syncFrames;
    }

    // Методы для левого фрейма
    public void setLeftFrameX(float x) {
        this.leftFrameX = x;
    }

    public float getLeftFrameX() {
        return leftFrameX;
    }

    public void setLeftFrameY(float y) {
        this.leftFrameY = y;
    }

    public float getLeftFrameY() {
        return leftFrameY;
    }

    public void setLeftFrameWidth(float width) {
        this.leftFrameWidth = width;
    }

    public float getLeftFrameWidth() {
        return leftFrameWidth;
    }

    public void setLeftFrameHeight(float height) {
        this.leftFrameHeight = height;
    }

    public float getLeftFrameHeight() {
        return leftFrameHeight;
    }

    // Методы для правого фрейма
    public void setRightFrameX(float x) {
        this.rightFrameX = x;
    }

    public float getRightFrameX() {
        return rightFrameX;
    }

    public void setRightFrameY(float y) {
        this.rightFrameY = y;
    }

    public float getRightFrameY() {
        return rightFrameY;
    }

    public void setRightFrameWidth(float width) {
        this.rightFrameWidth = width;
    }

    public float getRightFrameWidth() {
        return rightFrameWidth;
    }

    public void setRightFrameHeight(float height) {
        this.rightFrameHeight = height;
    }

    public float getRightFrameHeight() {
        return rightFrameHeight;
    }

    // Методы для параметров дисторсии
    public void setDistortionStrength(float strength) {
        this.distortionStrength = strength;
    }

    public float getDistortionStrength() {
        return distortionStrength;
    }

    public void setEdgeFeathering(float feathering) {
        this.edgeFeathering = feathering;
    }

    public float getEdgeFeathering() {
        return edgeFeathering;
    }

    public void setCornerRadius(float radius) {
        this.cornerRadius = radius;
    }

    public float getCornerRadius() {
        return cornerRadius;
    }

    // Метод для сброса к значениям по умолчанию
    public void resetToDefaults() {
        vrEnabled = false;
        showCenterLine = false;
        centerLineColor = 1.0f;
        vrMode = 0; // Split screen
        syncFrames = true;
        
        // Установка стандартных значений для Google Cardboard
        leftFrameX = 0.0f;
        leftFrameY = 0.0f;
        leftFrameWidth = 0.5f;  // Левая половина
        leftFrameHeight = 1.0f;
        
        rightFrameX = 0.5f;     // Правая половина
        rightFrameY = 0.0f;
        rightFrameWidth = 0.5f;
        rightFrameHeight = 1.0f;
        
        distortionStrength = 0.3f; // Дисторсия для компенсации линз
        edgeFeathering = 0.02f;   // Небольшое размытие краев
        cornerRadius = 0.05f;     // Малое закругление
    }

    // Методы для установки параметров фрейма (для совместимости)
    public void setLeftFrameParams(float x, float y, float width, float height) {
        this.leftFrameX = x;
        this.leftFrameY = y;
        this.leftFrameWidth = width;
        this.leftFrameHeight = height;
    }

    public void setRightFrameParams(float x, float y, float width, float height) {
        this.rightFrameX = x;
        this.rightFrameY = y;
        this.rightFrameWidth = width;
        this.rightFrameHeight = height;
    }

    // Методы для работы с профилями
    public VRProfile createProfile(String name) {
        return new VRProfile(name, this);
    }

    public void loadFromProfile(VRProfile profile) {
        profile.applyToEffect(this);
    }

    private class VREffectMaterial extends ScreenMaterial {
        public VREffectMaterial() {
            super();
            setUniformNames("resolution", "screenTexture", "vrEnabled", "showCenterLine", "centerLineColor", "vrMode",
                          "syncFrames",
                          "leftFrameX", "leftFrameY", "leftFrameWidth", "leftFrameHeight",
                          "rightFrameX", "rightFrameY", "rightFrameWidth", "rightFrameHeight",
                          "distortionStrength", "edgeFeathering", "cornerRadius");
        }

        @Override
        protected String getFragmentShader() {
            return String.join("\n", new CharSequence[]{
                "precision highp float;",
                "uniform vec2 resolution;",
                "uniform sampler2D screenTexture;",
                "uniform bool vrEnabled;",
                "uniform bool showCenterLine;",
                "uniform float centerLineColor;",
                "uniform int vrMode;",
                "uniform bool syncFrames;",
                "uniform float leftFrameX, leftFrameY, leftFrameWidth, leftFrameHeight;",
                "uniform float rightFrameX, rightFrameY, rightFrameWidth, rightFrameHeight;",
                "uniform float distortionStrength;",
                "uniform float edgeFeathering;",
                "uniform float cornerRadius;",
                "varying vec2 vUV;",

                // Функция коррекции "рыбий глаз" для компенсации искажения от линз
                "vec2 barrelDistortion(vec2 uv, float strength) {",
                "    vec2 centered = uv * 2.0 - 1.0; // Центрируем координаты",
                "    float r = length(centered); // Расстояние от центра",
                "    float theta = atan(centered.y, centered.x); // Угол",
                "    ",
                "    // Применяем кубическую дисторсию для компенсации",
                "    float distortion = 1.0 + strength * r * r + strength * strength * r * r * r * r;",
                "    ",
                "    // Ограничиваем искажение, чтобы избежать чрезмерного искажения на краях",
                "    distortion = min(distortion, 2.0);",
                "    ",
                "    vec2 corrected = distortion * centered;",
                "    ",
                "    // Возвращаем к нормализованным координатам",
                "    return (corrected + 1.0) * 0.5;",
                "}",

                // Функция для создания маски с закругленными углами для конкретного фрейма
                "float roundedFrameMask(vec2 uv, float frameX, float frameY, float frameWidth, float frameHeight, float radius) {",
                "    // Нормализуем координаты в систему координат фрейма",
                "    vec2 frameUV = (uv - vec2(frameX, frameY)) / vec2(frameWidth, frameHeight);",
                "    ",
                "    // Проверяем, внутри ли точка фрейма",
                "    if (frameUV.x < 0.0 || frameUV.x > 1.0 || frameUV.y < 0.0 || frameUV.y > 1.0) {",
                "        return 0.0; // Вне фрейма",
                "    }",
                "    ",
                "    // Рассчитываем радиус закругления в координатах фрейма",
                "    float cornerRadius = radius;",
                "    ",
                "    // Проверяем углы фрейма",
                "    vec2 cornerDist = vec2(0.0);",
                "    ",
                "    // Левый верхний угол",
                "    cornerDist = vec2(cornerRadius, cornerRadius) - frameUV;",
                "    if (cornerDist.x > 0.0 && cornerDist.y > 0.0) {",
                "        float dist = length(cornerDist);",
                "        if (dist > cornerRadius) return 0.0;",
                "    }",
                "    ",
                "    // Правый верхний угол",
                "    cornerDist = vec2(1.0 - cornerRadius, cornerRadius) - frameUV;",
                "    if (cornerDist.x < 0.0 && cornerDist.y > 0.0) {",
                "        float dist = length(cornerDist);",
                "        if (dist > cornerRadius) return 0.0;",
                "    }",
                "    ",
                "    // Левый нижний угол",
                "    cornerDist = vec2(cornerRadius, 1.0 - cornerRadius) - frameUV;",
                "    if (cornerDist.x > 0.0 && cornerDist.y < 0.0) {",
                "        float dist = length(cornerDist);",
                "        if (dist > cornerRadius) return 0.0;",
                "    }",
                "    ",
                "    // Правый нижний угол",
                "    cornerDist = vec2(1.0 - cornerRadius, 1.0 - cornerRadius) - frameUV;",
                "    if (cornerDist.x < 0.0 && cornerDist.y < 0.0) {",
                "        float dist = length(cornerDist);",
                "        if (dist > cornerRadius) return 0.0;",
                "    }",
                "    ",
                "    // Если мы дошли сюда, точка внутри фрейма с закругленными углами",
                "    return 1.0;",
                "}",

                "void main() {",
                "    if (!vrEnabled) {",
                "        // Обычный режим - просто выводим оригинальное изображение",
                "        gl_FragColor = texture2D(screenTexture, vUV);",
                "        return;",
                "    }",
                "",
                "    vec4 finalColor = vec4(0.0, 0.0, 0.0, 1.0);",
                "    ",
                "    // Обрабатываем левую половину экрана (левый глаз)",
                "    if (vUV.x < 0.5) {",
                "        // Вычисляем UV координаты для левого изображения",
                "        vec2 leftUV = vec2(",
                "            (vUV.x - leftFrameX) / leftFrameWidth,",
                "            (vUV.y - leftFrameY) / leftFrameHeight",
                "        );",
                "        ",
                "        // Проверяем, находится ли точка внутри левого фрейма",
                "        if (leftUV.x >= 0.0 && leftUV.x <= 1.0 && leftUV.y >= 0.0 && leftUV.y <= 1.0) {",
                "            // Применяем дисторсию 'рыбий глаз' для компенсации искажения от линз",
                "            vec2 distortedLeftUV = barrelDistortion(leftUV, distortionStrength);",
                "            ",
                "            // Проверяем, остались ли координаты в пределах",
                "            if (distortedLeftUV.x >= 0.0 && distortedLeftUV.x <= 1.0 &&",
                "                distortedLeftUV.y >= 0.0 && distortedLeftUV.y <= 1.0) {",
                "                ",
                "                // Применяем маску с закругленными углами для левого фрейма",
                "                float leftMask = roundedFrameMask(vUV, leftFrameX, leftFrameY, leftFrameWidth, leftFrameHeight, cornerRadius);",
                "                ",
                "                vec4 color = texture2D(screenTexture, distortedLeftUV);",
                "                finalColor = vec4(color.rgb * leftMask, color.a);",
                "            }",
                "        }",
                "    } else {",
                "        // Обрабатываем правую половину экрана (правый глаз)",
                "        vec2 rightUV;",
                "        ",
                "        if (syncFrames) {",
                "            // Если синхронизация включена, используем левые параметры для правого глаза",
                "            rightUV = vec2(",
                "                (vUV.x - (leftFrameX + 0.5)) / leftFrameWidth,",
                "                (vUV.y - leftFrameY) / leftFrameHeight",
                "            );",
                "        } else {",
                "            // Используем отдельные параметры для правого глаза",
                "            rightUV = vec2(",
                "                (vUV.x - rightFrameX) / rightFrameWidth,",
                "                (vUV.y - rightFrameY) / rightFrameHeight",
                "            );",
                "        }",
                "        ",
                "        // Проверяем, находится ли точка внутри правого фрейма",
                "        if (rightUV.x >= 0.0 && rightUV.x <= 1.0 && rightUV.y >= 0.0 && rightUV.y <= 1.0) {",
                "            // Применяем дисторсию 'рыбий глаз' для компенсации искажения от линз",
                "            vec2 distortedRightUV = barrelDistortion(rightUV, distortionStrength);",
                "            ",
                "            // Проверяем, остались ли координаты в пределах",
                "            if (distortedRightUV.x >= 0.0 && distortedRightUV.x <= 1.0 &&",
                "                distortedRightUV.y >= 0.0 && distortedRightUV.y <= 1.0) {",
                "                ",
                "                // Применяем маску с закругленными углами для правого фрейма",
                "                float rightMask;",
                "                if (syncFrames) {",
                "                    rightMask = roundedFrameMask(vUV, leftFrameX + 0.5, leftFrameY, leftFrameWidth, leftFrameHeight, cornerRadius);",
                "                } else {",
                "                    rightMask = roundedFrameMask(vUV, rightFrameX, rightFrameY, rightFrameWidth, rightFrameHeight, cornerRadius);",
                "                }",
                "                ",
                "                vec4 color = texture2D(screenTexture, distortedRightUV);",
                "                finalColor = vec4(color.rgb * rightMask, color.a);",
                "            }",
                "        }",
                "    }",
                "    ",
                "    // Добавляем вертикальную линию по центру экрана, если нужно",
                "    if (showCenterLine) {",
                "        float centerLineWidth = 0.002; // Толщина линии (0.2% ширины экрана)",
                "        float centerLinePosition = 0.5; // Центр экрана",
                "        float distanceFromCenter = abs(vUV.x - centerLinePosition);",
                "        float lineMask = 1.0 - smoothstep(0.0, centerLineWidth, distanceFromCenter);",
                "        vec3 lineColor = vec3(centerLineColor);",
                "        finalColor = mix(finalColor, vec4(lineColor, 1.0), lineMask);",
                "    }",
                "    ",
                "    gl_FragColor = finalColor;",
                "}"
            });
        }

        @Override
        public void use() {
            super.use();

            setUniformInt("vrEnabled", vrEnabled ? 1 : 0);
            setUniformInt("showCenterLine", showCenterLine ? 1 : 0);
            setUniformFloat("centerLineColor", centerLineColor);
            setUniformInt("vrMode", vrMode);
            setUniformInt("syncFrames", syncFrames ? 1 : 0);
            
            // Устанавливаем параметры фреймов
            setUniformFloat("leftFrameX", leftFrameX);
            setUniformFloat("leftFrameY", leftFrameY);
            setUniformFloat("leftFrameWidth", leftFrameWidth);
            setUniformFloat("leftFrameHeight", leftFrameHeight);
            
            setUniformFloat("rightFrameX", rightFrameX);
            setUniformFloat("rightFrameY", rightFrameY);
            setUniformFloat("rightFrameWidth", rightFrameWidth);
            setUniformFloat("rightFrameHeight", rightFrameHeight);
            
            // Устанавливаем параметры дисторсии и закругления
            setUniformFloat("distortionStrength", distortionStrength);
            setUniformFloat("edgeFeathering", edgeFeathering);
            setUniformFloat("cornerRadius", cornerRadius);
        }
    }
}