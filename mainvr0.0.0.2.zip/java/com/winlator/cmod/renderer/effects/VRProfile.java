package com.winlator.cmod.renderer.effects;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VRProfile {
    private String name;
    private boolean enabled;
    private boolean showCenterLine;
    private float centerLineColor;
    private boolean syncFrames;
    private int vrMode;
    private float leftFrameX, leftFrameY, leftFrameWidth, leftFrameHeight;
    private float rightFrameX, rightFrameY, rightFrameWidth, rightFrameHeight;
    private float distortionStrength;
    private float edgeFeathering;
    private float cornerRadius;

    public VRProfile() {
        resetToDefaults();
    }

    public VRProfile(String name) {
        this.name = name;
        resetToDefaults();
    }

    public VRProfile(String name, VREffect effect) {
        this.name = name;
        loadFromEffect(effect);
    }

    public void loadFromEffect(VREffect effect) {
        this.enabled = effect.isVREnabled();
        this.showCenterLine = effect.isShowCenterLine();
        this.centerLineColor = effect.getCenterLineColor();
        this.syncFrames = effect.isSyncFrames();
        this.vrMode = effect.getVrMode();
        this.leftFrameX = effect.getLeftFrameX();
        this.leftFrameY = effect.getLeftFrameY();
        this.leftFrameWidth = effect.getLeftFrameWidth();
        this.leftFrameHeight = effect.getLeftFrameHeight();
        this.rightFrameX = effect.getRightFrameX();
        this.rightFrameY = effect.getRightFrameY();
        this.rightFrameWidth = effect.getRightFrameWidth();
        this.rightFrameHeight = effect.getRightFrameHeight();
        this.distortionStrength = effect.getDistortionStrength();
        this.edgeFeathering = effect.getEdgeFeathering();
        this.cornerRadius = effect.getCornerRadius();
    }

    public void applyToEffect(VREffect effect) {
        effect.setVREnabled(this.enabled);
        effect.setShowCenterLine(this.showCenterLine);
        effect.setCenterLineColor(this.centerLineColor);
        effect.setSyncFrames(this.syncFrames);
        effect.setVrMode(this.vrMode);
        effect.setLeftFrameX(this.leftFrameX);
        effect.setLeftFrameY(this.leftFrameY);
        effect.setLeftFrameWidth(this.leftFrameWidth);
        effect.setLeftFrameHeight(this.leftFrameHeight);
        effect.setRightFrameX(this.rightFrameX);
        effect.setRightFrameY(this.rightFrameY);
        effect.setRightFrameWidth(this.rightFrameWidth);
        effect.setRightFrameHeight(this.rightFrameHeight);
        effect.setDistortionStrength(this.distortionStrength);
        effect.setEdgeFeathering(this.edgeFeathering);
        effect.setCornerRadius(this.cornerRadius);
    }

    public void resetToDefaults() {
        this.name = "Default";
        this.enabled = false;
        this.showCenterLine = false;
        this.centerLineColor = 1.0f;
        this.syncFrames = true;
        this.vrMode = 0; // Split screen
        this.leftFrameX = 0.0f;
        this.leftFrameY = 0.0f;
        this.leftFrameWidth = 0.5f;  // Левая половина
        this.leftFrameHeight = 1.0f;
        this.rightFrameX = 0.5f;     // Правая половина
        this.rightFrameY = 0.0f;
        this.rightFrameWidth = 0.5f;
        this.rightFrameHeight = 1.0f;
        this.distortionStrength = 0.3f;
        this.edgeFeathering = 0.02f;
        this.cornerRadius = 0.05f;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isShowCenterLine() {
        return showCenterLine;
    }

    public void setShowCenterLine(boolean showCenterLine) {
        this.showCenterLine = showCenterLine;
    }

    public float getCenterLineColor() {
        return centerLineColor;
    }

    public void setCenterLineColor(float centerLineColor) {
        this.centerLineColor = centerLineColor;
    }

    public boolean isSyncFrames() {
        return syncFrames;
    }

    public void setSyncFrames(boolean syncFrames) {
        this.syncFrames = syncFrames;
    }

    public int getVrMode() {
        return vrMode;
    }

    public void setVrMode(int vrMode) {
        this.vrMode = vrMode;
    }

    public float getLeftFrameX() {
        return leftFrameX;
    }

    public void setLeftFrameX(float leftFrameX) {
        this.leftFrameX = leftFrameX;
    }

    public float getLeftFrameY() {
        return leftFrameY;
    }

    public void setLeftFrameY(float leftFrameY) {
        this.leftFrameY = leftFrameY;
    }

    public float getLeftFrameWidth() {
        return leftFrameWidth;
    }

    public void setLeftFrameWidth(float leftFrameWidth) {
        this.leftFrameWidth = leftFrameWidth;
    }

    public float getLeftFrameHeight() {
        return leftFrameHeight;
    }

    public void setLeftFrameHeight(float leftFrameHeight) {
        this.leftFrameHeight = leftFrameHeight;
    }

    public float getRightFrameX() {
        return rightFrameX;
    }

    public void setRightFrameX(float rightFrameX) {
        this.rightFrameX = rightFrameX;
    }

    public float getRightFrameY() {
        return rightFrameY;
    }

    public void setRightFrameY(float rightFrameY) {
        this.rightFrameY = rightFrameY;
    }

    public float getRightFrameWidth() {
        return rightFrameWidth;
    }

    public void setRightFrameWidth(float rightFrameWidth) {
        this.rightFrameWidth = rightFrameWidth;
    }

    public float getRightFrameHeight() {
        return rightFrameHeight;
    }

    public void setRightFrameHeight(float rightFrameHeight) {
        this.rightFrameHeight = rightFrameHeight;
    }

    public float getDistortionStrength() {
        return distortionStrength;
    }

    public void setDistortionStrength(float distortionStrength) {
        this.distortionStrength = distortionStrength;
    }

    public float getEdgeFeathering() {
        return edgeFeathering;
    }

    public void setEdgeFeathering(float edgeFeathering) {
        this.edgeFeathering = edgeFeathering;
    }

    public float getCornerRadius() {
        return cornerRadius;
    }

    public void setCornerRadius(float cornerRadius) {
        this.cornerRadius = cornerRadius;
    }

    // JSON serialization
    public JSONObject toJSON() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("name", name);
        json.put("enabled", enabled);
        json.put("showCenterLine", showCenterLine);
        json.put("centerLineColor", centerLineColor);
        json.put("syncFrames", syncFrames);
        json.put("vrMode", vrMode);
        json.put("leftFrameX", leftFrameX);
        json.put("leftFrameY", leftFrameY);
        json.put("leftFrameWidth", leftFrameWidth);
        json.put("leftFrameHeight", leftFrameHeight);
        json.put("rightFrameX", rightFrameX);
        json.put("rightFrameY", rightFrameY);
        json.put("rightFrameWidth", rightFrameWidth);
        json.put("rightFrameHeight", rightFrameHeight);
        json.put("distortionStrength", distortionStrength);
        json.put("edgeFeathering", edgeFeathering);
        json.put("cornerRadius", cornerRadius);
        return json;
    }

    public static VRProfile fromJSON(JSONObject json) throws JSONException {
        VRProfile profile = new VRProfile();
        profile.name = json.getString("name");
        profile.enabled = json.getBoolean("enabled");
        profile.showCenterLine = json.getBoolean("showCenterLine");
        profile.centerLineColor = (float) json.getDouble("centerLineColor");
        profile.syncFrames = json.getBoolean("syncFrames");
        profile.vrMode = json.getInt("vrMode");
        profile.leftFrameX = (float) json.getDouble("leftFrameX");
        profile.leftFrameY = (float) json.getDouble("leftFrameY");
        profile.leftFrameWidth = (float) json.getDouble("leftFrameWidth");
        profile.leftFrameHeight = (float) json.getDouble("leftFrameHeight");
        profile.rightFrameX = (float) json.getDouble("rightFrameX");
        profile.rightFrameY = (float) json.getDouble("rightFrameY");
        profile.rightFrameWidth = (float) json.getDouble("rightFrameWidth");
        profile.rightFrameHeight = (float) json.getDouble("rightFrameHeight");
        profile.distortionStrength = (float) json.getDouble("distortionStrength");
        profile.edgeFeathering = (float) json.getDouble("edgeFeathering");
        profile.cornerRadius = (float) json.getDouble("cornerRadius");
        return profile;
    }
}