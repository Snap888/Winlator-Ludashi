package com.winlator.cmod.renderer.effects;

import android.opengl.GLES20;
import android.util.Log;

import com.winlator.cmod.renderer.GLRenderer;
import com.winlator.cmod.renderer.material.ScreenMaterial;

public class VREffect extends Effect {
    private boolean vrEnabled = false;
    private boolean syncFrames = true;
    private int vrMode = 0; // 0=Split Screen, 1=Side-by-Side, 2=Over-Under
    private float leftFrameX = 0.0f, leftFrameY = 0.0f, leftFrameWidth = 0.5f, leftFrameHeight = 1.0f;
    private float rightFrameX = 0.5f, rightFrameY = 0.0f, rightFrameWidth = 0.5f, rightFrameHeight = 1.0f;
    private float distortionStrength = 0.0f; // Убираем дисторсию для простоты
    private float edgeFeathering = 0.0f;
    private float cornerRadius = 0.0f;
    private GLRenderer renderer;

    public VREffect() {
        super();
    }

    public void setRenderer(GLRenderer renderer) {
        this.renderer = renderer;
    }

    @Override
    protected ScreenMaterial createMaterial() {
        return new VREffectMaterial();
    }

    // Методы для управления VR режимом
    public void setEnabled(boolean enabled) {
        this.vrEnabled = enabled;
    }

    public boolean isEnabled() {
        return vrEnabled;
    }

    public void setVREnabled(boolean enabled) {
        this.vrEnabled = enabled;
    }

    public boolean isVREnabled() {
        return vrEnabled;
    }

    // Методы для VR режима
    public void setVrMode(int mode) {
        this.vrMode = mode;
    }

    public int getVrMode() {
        return vrMode;
    }

    // Методы для синхронизации фреймов
    public void setSyncFrames(boolean sync) {
        this.syncFrames = sync;
    }

    public boolean isSyncFrames() {
        return syncFrames;
    }

    // Методы для левого фрейма
    public void setLeftFrameX(float x) {
        this.leftFrameX = x;
    }

    public float getLeftFrameX() {
        return leftFrameX;
    }

    public void setLeftFrameY(float y) {
        this.leftFrameY = y;
    }

    public float getLeftFrameY() {
        return leftFrameY;
    }

    public void setLeftFrameWidth(float width) {
        this.leftFrameWidth = width;
    }

    public float getLeftFrameWidth() {
        return leftFrameWidth;
    }

    public void setLeftFrameHeight(float height) {
        this.leftFrameHeight = height;
    }

    public float getLeftFrameHeight() {
        return leftFrameHeight;
    }

    // Методы для правого фрейма
    public void setRightFrameX(float x) {
        this.rightFrameX = x;
    }

    public float getRightFrameX() {
        return rightFrameX;
    }

    public void setRightFrameY(float y) {
        this.rightFrameY = y;
    }

    public float getRightFrameY() {
        return rightFrameY;
    }

    public void setRightFrameWidth(float width) {
        this.rightFrameWidth = width;
    }

    public float getRightFrameWidth() {
        return rightFrameWidth;
    }

    public void setRightFrameHeight(float height) {
        this.rightFrameHeight = height;
    }

    public float getRightFrameHeight() {
        return rightFrameHeight;
    }

    // Методы для параметров дисторсии
    public void setDistortionStrength(float strength) {
        this.distortionStrength = strength;
    }

    public float getDistortionStrength() {
        return distortionStrength;
    }

    public void setEdgeFeathering(float feathering) {
        this.edgeFeathering = feathering;
    }

    public float getEdgeFeathering() {
        return edgeFeathering;
    }

    public void setCornerRadius(float radius) {
        this.cornerRadius = radius;
    }

    public float getCornerRadius() {
        return cornerRadius;
    }

    // Метод для сброса к значениям по умолчанию
    public void resetToDefaults() {
        vrEnabled = false;
        vrMode = 0; // Split screen
        syncFrames = true;
        
        // Установка стандартных значений для Google Cardboard
        leftFrameX = 0.0f;
        leftFrameY = 0.0f;
        leftFrameWidth = 0.5f;  // Левая половина
        leftFrameHeight = 1.0f;
        
        rightFrameX = 0.5f;     // Правая половина
        rightFrameY = 0.0f;
        rightFrameWidth = 0.5f;
        rightFrameHeight = 1.0f;
        
        distortionStrength = 0.0f;
        edgeFeathering = 0.0f;
        cornerRadius = 0.0f;
    }

    // Методы для установки параметров фрейма (для совместимости)
    public void setLeftFrameParams(float x, float y, float width, float height) {
        this.leftFrameX = x;
        this.leftFrameY = y;
        this.leftFrameWidth = width;
        this.leftFrameHeight = height;
    }

    public void setRightFrameParams(float x, float y, float width, float height) {
        this.rightFrameX = x;
        this.rightFrameY = y;
        this.rightFrameWidth = width;
        this.rightFrameHeight = height;
    }

    private class VREffectMaterial extends ScreenMaterial {
        public VREffectMaterial() {
            super();
            setUniformNames("resolution", "screenTexture", "vrEnabled", "vrMode",
                          "syncFrames",
                          "leftFrameX", "leftFrameY", "leftFrameWidth", "leftFrameHeight",
                          "rightFrameX", "rightFrameY", "rightFrameWidth", "rightFrameHeight",
                          "distortionStrength", "edgeFeathering", "cornerRadius");
        }

        @Override
        protected String getFragmentShader() {
            return String.join("\n", new CharSequence[]{
                "precision highp float;",
                "uniform vec2 resolution;",
                "uniform sampler2D screenTexture;",
                "uniform bool vrEnabled;",
                "uniform int vrMode;",
                "uniform bool syncFrames;",
                "uniform float leftFrameX, leftFrameY, leftFrameWidth, leftFrameHeight;",
                "uniform float rightFrameX, rightFrameY, rightFrameWidth, rightFrameHeight;",
                "uniform float distortionStrength;",
                "uniform float edgeFeathering;",
                "uniform float cornerRadius;",
                "varying vec2 vUV;",

                "void main() {",
                "    if (!vrEnabled) {",
                "        // Обычный режим - просто выводим оригинальное изображение",
                "        gl_FragColor = texture2D(screenTexture, vUV);",
                "        return;",
                "    }",
                "",
                "    // Определяем, какую половину экрана мы рендерим",
                "    if (vUV.x < 0.5) {",  // Левая половина экрана",
                "        // Вычисляем UV координаты для левого изображения",
                "        vec2 leftUV = vec2(",
                "            (vUV.x - leftFrameX) / leftFrameWidth,",
                "            (vUV.y - leftFrameY) / leftFrameHeight",
                "        );",
                "        // Проверяем, находится ли точка внутри левого фрейма",
                "        if (leftUV.x >= 0.0 && leftUV.x <= 1.0 && leftUV.y >= 0.0 && leftUV.y <= 1.0) {",
                "            gl_FragColor = texture2D(screenTexture, leftUV);",
                "        } else {",
                "            // Вне фрейма - черный цвет",
                "            gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);",
                "        }",
                "    } else {",  // Правая половина экрана",
                "        vec2 rightUV;",
                "        if (syncFrames) {",
                "            // Если синхронизация включена, используем левые параметры для правого глаза",
                "            rightUV = vec2(",
                "                (vUV.x - (leftFrameX + 0.5)) / leftFrameWidth,",
                "                (vUV.y - leftFrameY) / leftFrameHeight",
                "            );",
                "        } else {",
                "            // Используем отдельные параметры для правого глаза",
                "            rightUV = vec2(",
                "                (vUV.x - rightFrameX) / rightFrameWidth,",
                "                (vUV.y - rightFrameY) / rightFrameHeight",
                "            );",
                "        }",
                "        // Проверяем, находится ли точка внутри правого фрейма",
                "        if (rightUV.x >= 0.0 && rightUV.x <= 1.0 && rightUV.y >= 0.0 && rightUV.y <= 1.0) {",
                "            gl_FragColor = texture2D(screenTexture, rightUV);",
                "        } else {",
                "            // Вне фрейма - черный цвет",
                "            gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);",
                "        }",
                "    }",
                "}"
            });
        }

        @Override
        public void use() {
            super.use();

            setUniformInt("vrEnabled", vrEnabled ? 1 : 0);
            setUniformInt("vrMode", vrMode);
            setUniformInt("syncFrames", syncFrames ? 1 : 0);
            
            // Устанавливаем параметры фреймов
            setUniformFloat("leftFrameX", leftFrameX);
            setUniformFloat("leftFrameY", leftFrameY);
            setUniformFloat("leftFrameWidth", leftFrameWidth);
            setUniformFloat("leftFrameHeight", leftFrameHeight);
            
            setUniformFloat("rightFrameX", rightFrameX);
            setUniformFloat("rightFrameY", rightFrameY);
            setUniformFloat("rightFrameWidth", rightFrameWidth);
            setUniformFloat("rightFrameHeight", rightFrameHeight);
            
            // Устанавливаем параметры дисторсии (не используются в этой версии, но для совместимости)
            setUniformFloat("distortionStrength", distortionStrength);
            setUniformFloat("edgeFeathering", edgeFeathering);
            setUniformFloat("cornerRadius", cornerRadius);
        }
    }
}